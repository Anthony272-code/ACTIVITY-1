# TaskSpace — Activity 1 + Activity 2

This starter website combines the two assignment requirements:

- **Activity 1:** Sign In and Register pages.
- **Activity 2:** Access control, user management, and CRUD operations.

## Requirements
- Install Node.js (LTS): https://nodejs.org/
- Visual Studio Code

## Run in VS Code
1. Extract this ZIP file.
2. Open the extracted `activity2-auth-crud` folder in VS Code.
3. Open Terminal → New Terminal.
4. Run `npm install`.
5. Run `npm start`.
6. Open http://localhost:3000 in your browser.

## Default administrator account
- Email: `admin@example.com`
- Password: `admin123`

Register another account to test the normal-user role. Normal users can only manage their own tasks. Admins can manage users and all tasks.

## Features
- Password hashing with bcryptjs.
- Session-based login.
- Role-based admin route and API protection.
- User management: read, update name/role, delete.
- Task CRUD: create, read, update, delete.
- JSON file storage in `data/db.json` (created automatically).

## Important
This is a classroom/demo starter project. Before deploying publicly, use a strong session secret, HTTPS, CSRF protection, rate limiting, and a production database. The default admin password is for local testing only; change it before any real deployment.
