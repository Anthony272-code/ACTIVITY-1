async function sendForm(form, endpoint) {
  const message = document.getElementById("message");
  const button = form.querySelector("button");
  button.disabled = true; button.textContent = "Please wait...";
  try {
    const response = await fetch(endpoint, { method: "POST", body: new URLSearchParams(new FormData(form)) });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Something went wrong.");
    location.href = "/dashboard";
  } catch (error) {
    message.textContent = error.message; message.className = "message error";
    button.disabled = false; button.textContent = endpoint.includes("login") ? "Sign In" : "Create Account";
  }
}
document.getElementById("loginForm")?.addEventListener("submit", e => { e.preventDefault(); sendForm(e.target, "/api/login"); });
document.getElementById("registerForm")?.addEventListener("submit", e => { e.preventDefault(); sendForm(e.target, "/api/register"); });
