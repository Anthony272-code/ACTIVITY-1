const $ = id => document.getElementById(id);
async function api(url, options={}) {
 const r=await fetch(url,{headers:{"Content-Type":"application/json"},...options}); const d=await r.json().catch(()=>({}));
 if(!r.ok) throw new Error(d.error||"Request failed."); return d;
}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
async function load(){
 try{
  const users=await api("/api/users"); $("count").textContent=`${users.length} account(s)`;
  $("users").innerHTML=users.map(u=>`<tr><td><input id="name-${u.id}" value="${esc(u.name)}"></td><td>${esc(u.email)}</td><td><select id="role-${u.id}"><option value="user" ${u.role==="user"?"selected":""}>User</option><option value="admin" ${u.role==="admin"?"selected":""}>Admin</option></select></td><td class="table-actions"><button class="primary" onclick="saveUser(${u.id})">Save</button> <button class="danger" onclick="removeUser(${u.id})">Delete</button></td></tr>`).join("");
 }catch(e){$("message").textContent=e.message; $("message").className="message error"; if(e.message.includes("403")) setTimeout(()=>location.href="/dashboard",1500);}
}
async function saveUser(id){try{await api(`/api/users/${id}`,{method:"PUT",body:JSON.stringify({name:$(`name-${id}`).value,role:$(`role-${id}`).value})});$("message").textContent="User updated."; $("message").className="message success";load();}catch(e){$("message").textContent=e.message;$("message").className="message error";}}
async function removeUser(id){if(!confirm("Delete this user and their tasks?"))return;try{await api(`/api/users/${id}`,{method:"DELETE"});load();}catch(e){$("message").textContent=e.message;$("message").className="message error";}}
$("logout").addEventListener("click",async()=>{await fetch("/api/logout",{method:"POST"});location.href="/login.html";});
load();
