let editingId = null;
const $ = id => document.getElementById(id);
async function api(url, options={}) {
  const res = await fetch(url, { headers: { "Content-Type": "application/json" }, ...options });
  const data = res.status === 204 ? {} : await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || "Request failed."); return data;
}
async function init() {
  try {
    const me = await api("/api/me");
    $("welcome").textContent = `${me.name} · ${me.role}`;
    if (me.role === "admin") $("adminLink").classList.remove("hidden");
    await loadTasks();
  } catch { location.href = "/login.html"; }
}
async function loadTasks() {
  const tasks = await api("/api/tasks");
  $("count").textContent = `${tasks.length} item(s)`;
  $("tasks").innerHTML = tasks.length ? tasks.map(t => `<article class="task-card"><div><h3>${escapeHTML(t.title)}</h3><p>${escapeHTML(t.description || "No description")}</p></div><div class="task-actions"><button class="outline" onclick="editTask(${t.id})">Edit</button><button class="danger" onclick="deleteTask(${t.id})">Delete</button></div></article>`).join("") : '<div class="empty">No tasks yet. Add your first task above.</div>';
}
function escapeHTML(s) { return String(s).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }
$("taskForm").addEventListener("submit", async e => {
  e.preventDefault();
  try {
    const body = JSON.stringify({ title: $("taskTitle").value, description: $("taskDescription").value });
    await api(editingId ? `/api/tasks/${editingId}` : "/api/tasks", { method: editingId ? "PUT" : "POST", body });
    resetForm(); $("message").textContent = "Saved successfully."; $("message").className = "message success"; await loadTasks();
  } catch(err) { $("message").textContent = err.message; $("message").className = "message error"; }
});
async function editTask(id) {
  const tasks = await api("/api/tasks"), task = tasks.find(t => t.id === id); if (!task) return;
  editingId = id; $("taskTitle").value = task.title; $("taskDescription").value = task.description;
  $("formTitle").textContent = "Edit task"; $("saveButton").textContent = "Save Changes"; $("cancelEdit").classList.remove("hidden"); window.scrollTo({top:0,behavior:"smooth"});
}
async function deleteTask(id) {
  if (!confirm("Delete this task?")) return;
  try { await api(`/api/tasks/${id}`, {method:"DELETE"}); await loadTasks(); } catch(e) { alert(e.message); }
}
function resetForm() { editingId=null; $("taskForm").reset(); $("formTitle").textContent="Add a task"; $("saveButton").textContent="Add Task"; $("cancelEdit").classList.add("hidden"); }
$("cancelEdit").addEventListener("click", resetForm);
$("logout").addEventListener("click", async () => { await fetch("/api/logout",{method:"POST"}); location.href="/login.html"; });
init();
