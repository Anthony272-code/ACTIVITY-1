const express = require("express");
const session = require("express-session");
const bcrypt = require("bcryptjs");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_DIR = path.join(__dirname, "data");
const DB_FILE = path.join(DATA_DIR, "db.json");

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR);
if (!fs.existsSync(DB_FILE)) {
  const adminHash = bcrypt.hashSync("admin123", 10);
  fs.writeFileSync(DB_FILE, JSON.stringify({
    users: [{ id: 1, name: "Administrator", email: "admin@example.com", password: adminHash, role: "admin" }],
    tasks: [
      { id: 1, userId: 1, title: "Welcome to your dashboard", description: "Create, edit, and delete your own tasks here.", createdAt: new Date().toISOString() }
    ],
    nextUserId: 2,
    nextTaskId: 2
  }, null, 2));
}

function readDB() { return JSON.parse(fs.readFileSync(DB_FILE, "utf8")); }
function writeDB(db) { fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2)); }

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(session({
  secret: process.env.SESSION_SECRET || "change-this-secret-before-deployment",
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", maxAge: 1000 * 60 * 60 * 3 }
}));
app.use(express.static(path.join(__dirname, "public")));

function currentUser(req) {
  if (!req.session.userId) return null;
  return readDB().users.find(u => u.id === req.session.userId) || null;
}
function requireLogin(req, res, next) {
  if (!currentUser(req)) return res.redirect("/login.html");
  next();
}
function requireAdmin(req, res, next) {
  const user = currentUser(req);
  if (!user) return res.redirect("/login.html");
  if (user.role !== "admin") return res.status(403).send("403 - Admin access only. <a href='/dashboard'>Go back</a>");
  next();
}
function safeUser(user) {
  return { id: user.id, name: user.name, email: user.email, role: user.role };
}

app.get("/", (req, res) => res.redirect(currentUser(req) ? "/dashboard" : "/login.html"));

app.post("/api/register", async (req, res) => {
  const name = String(req.body.name || "").trim();
  const email = String(req.body.email || "").trim().toLowerCase();
  const password = String(req.body.password || "");
  if (!name || !email || password.length < 6)
    return res.status(400).json({ error: "Enter your name, a valid email, and a password with at least 6 characters." });
  const db = readDB();
  if (db.users.some(u => u.email === email)) return res.status(409).json({ error: "That email is already registered." });
  const user = { id: db.nextUserId++, name, email, password: await bcrypt.hash(password, 10), role: "user" };
  db.users.push(user);
  writeDB(db);
  req.session.userId = user.id;
  res.json({ ok: true });
});

app.post("/api/login", async (req, res) => {
  const email = String(req.body.email || "").trim().toLowerCase();
  const password = String(req.body.password || "");
  const user = readDB().users.find(u => u.email === email);
  if (!user || !(await bcrypt.compare(password, user.password)))
    return res.status(401).json({ error: "Incorrect email or password." });
  req.session.userId = user.id;
  res.json({ ok: true });
});

app.post("/api/logout", (req, res) => {
  req.session.destroy(() => res.redirect("/login.html"));
});

app.get("/api/me", requireLogin, (req, res) => res.json(safeUser(currentUser(req))));

app.get("/dashboard", requireLogin, (req, res) => res.sendFile(path.join(__dirname, "public", "dashboard.html")));
app.get("/admin", requireAdmin, (req, res) => res.sendFile(path.join(__dirname, "public", "admin.html")));

app.get("/api/tasks", requireLogin, (req, res) => {
  const user = currentUser(req);
  const db = readDB();
  const tasks = user.role === "admin" ? db.tasks : db.tasks.filter(t => t.userId === user.id);
  res.json(tasks);
});
app.post("/api/tasks", requireLogin, (req, res) => {
  const title = String(req.body.title || "").trim();
  const description = String(req.body.description || "").trim();
  if (!title) return res.status(400).json({ error: "Task title is required." });
  const db = readDB();
  const task = { id: db.nextTaskId++, userId: currentUser(req).id, title, description, createdAt: new Date().toISOString() };
  db.tasks.push(task); writeDB(db); res.status(201).json(task);
});
app.put("/api/tasks/:id", requireLogin, (req, res) => {
  const db = readDB(), id = Number(req.params.id), user = currentUser(req);
  const task = db.tasks.find(t => t.id === id);
  if (!task) return res.status(404).json({ error: "Task not found." });
  if (user.role !== "admin" && task.userId !== user.id) return res.sendStatus(403);
  const title = String(req.body.title || "").trim();
  if (!title) return res.status(400).json({ error: "Task title is required." });
  task.title = title; task.description = String(req.body.description || "").trim();
  writeDB(db); res.json(task);
});
app.delete("/api/tasks/:id", requireLogin, (req, res) => {
  const db = readDB(), id = Number(req.params.id), user = currentUser(req);
  const task = db.tasks.find(t => t.id === id);
  if (!task) return res.status(404).json({ error: "Task not found." });
  if (user.role !== "admin" && task.userId !== user.id) return res.sendStatus(403);
  db.tasks = db.tasks.filter(t => t.id !== id); writeDB(db); res.json({ ok: true });
});

// Admin-only user management
app.get("/api/users", requireAdmin, (req, res) => res.json(readDB().users.map(safeUser)));
app.put("/api/users/:id", requireAdmin, (req, res) => {
  const db = readDB(), user = db.users.find(u => u.id === Number(req.params.id));
  if (!user) return res.status(404).json({ error: "User not found." });
  const name = String(req.body.name || "").trim();
  const role = req.body.role === "admin" ? "admin" : "user";
  if (!name) return res.status(400).json({ error: "Name is required." });
  if (user.id === currentUser(req).id && role !== "admin") return res.status(400).json({ error: "You cannot remove your own admin role." });
  user.name = name; user.role = role; writeDB(db); res.json(safeUser(user));
});
app.delete("/api/users/:id", requireAdmin, (req, res) => {
  const db = readDB(), id = Number(req.params.id);
  if (id === currentUser(req).id) return res.status(400).json({ error: "You cannot delete your own account." });
  if (!db.users.some(u => u.id === id)) return res.status(404).json({ error: "User not found." });
  db.users = db.users.filter(u => u.id !== id);
  db.tasks = db.tasks.filter(t => t.userId !== id);
  writeDB(db); res.json({ ok: true });
});

app.listen(PORT, () => console.log(`Website running at http://localhost:${PORT}`));
